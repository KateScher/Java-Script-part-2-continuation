const data = `[
  {
    "img": "1.jpg",
    "title": "ELLERY X M'O CAPSULE",
    "description": "ELLERY X M'O CAPSULE",
    "price": "$52"
  },
  {
    "img": "2.jpg",
    "title": "ELLERY X M'O CAPSULE",
    "description": "ELLERY X M'O CAPSULE",
    "price": "$52"
  },
  {
    "img": "3.jpg",
    "title": "ELLERY X M'O CAPSULE",
    "description": "ELLERY X M'O CAPSULE",
    "price": "$52"
  },
  {
    "img": "4.jpg",
    "title": "ELLERY X M'O CAPSULE",
    "description": "ELLERY X M'O CAPSULE",
    "price": "$52"
  },
  {
    "img": "5.jpg",
    "title": "ELLERY X M'O CAPSULE",
    "description": "ELLERY X M'O CAPSULE",
    "price": "$52"
  },
  {
    "img": "6.jpg",
    "title": "ELLERY X M'O CAPSULE",
    "description": "ELLERY X M'O CAPSULE",
    "price": "$52"
  }
]`;
